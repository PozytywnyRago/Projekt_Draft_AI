-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: liga
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `champions`
--

DROP TABLE IF EXISTS `champions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `champions` (
  `champ_id` bigint NOT NULL AUTO_INCREMENT,
  `image` varchar(255) DEFAULT NULL,
  `champion_key` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`champ_id`)
) ENGINE=InnoDB AUTO_INCREMENT=688 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `champions`
--

LOCK TABLES `champions` WRITE;
/*!40000 ALTER TABLE `champions` DISABLE KEYS */;
INSERT INTO `champions` VALUES (516,'Aatrox.png','266','Aatrox','Aatrox'),(517,'Ahri.png','103','Ahri','Ahri'),(518,'Akali.png','84','Akali','Akali'),(519,'Akshan.png','166','Akshan','Akshan'),(520,'Alistar.png','12','Alistar','Alistar'),(521,'Ambessa.png','799','Ambessa','Ambessa'),(522,'Amumu.png','32','Amumu','Amumu'),(523,'Anivia.png','34','Anivia','Anivia'),(524,'Annie.png','1','Annie','Annie'),(525,'Aphelios.png','523','Aphelios','Aphelios'),(526,'Ashe.png','22','Ashe','Ashe'),(527,'AurelionSol.png','136','Aurelion Sol','AurelionSol'),(528,'Aurora.png','893','Aurora','Aurora'),(529,'Azir.png','268','Azir','Azir'),(530,'Bard.png','432','Bard','Bard'),(531,'Belveth.png','200','Bel\'Veth','Belveth'),(532,'Blitzcrank.png','53','Blitzcrank','Blitzcrank'),(533,'Brand.png','63','Brand','Brand'),(534,'Braum.png','201','Braum','Braum'),(535,'Briar.png','233','Briar','Briar'),(536,'Caitlyn.png','51','Caitlyn','Caitlyn'),(537,'Camille.png','164','Camille','Camille'),(538,'Cassiopeia.png','69','Cassiopeia','Cassiopeia'),(539,'Chogath.png','31','Cho\'Gath','Chogath'),(540,'Corki.png','42','Corki','Corki'),(541,'Darius.png','122','Darius','Darius'),(542,'Diana.png','131','Diana','Diana'),(543,'Draven.png','119','Draven','Draven'),(544,'DrMundo.png','36','Dr Mundo','DrMundo'),(545,'Ekko.png','245','Ekko','Ekko'),(546,'Elise.png','60','Elise','Elise'),(547,'Evelynn.png','28','Evelynn','Evelynn'),(548,'Ezreal.png','81','Ezreal','Ezreal'),(549,'Fiddlesticks.png','9','Fiddlesticks','Fiddlesticks'),(550,'Fiora.png','114','Fiora','Fiora'),(551,'Fizz.png','105','Fizz','Fizz'),(552,'Galio.png','3','Galio','Galio'),(553,'Gangplank.png','41','Gangplank','Gangplank'),(554,'Garen.png','86','Garen','Garen'),(555,'Gnar.png','150','Gnar','Gnar'),(556,'Gragas.png','79','Gragas','Gragas'),(557,'Graves.png','104','Graves','Graves'),(558,'Gwen.png','887','Gwen','Gwen'),(559,'Hecarim.png','120','Hecarim','Hecarim'),(560,'Heimerdinger.png','74','Heimerdinger','Heimerdinger'),(561,'Hwei.png','910','Hwei','Hwei'),(562,'Illaoi.png','420','Illaoi','Illaoi'),(563,'Irelia.png','39','Irelia','Irelia'),(564,'Ivern.png','427','Ivern','Ivern'),(565,'Janna.png','40','Janna','Janna'),(566,'JarvanIV.png','59','Jarvan IV','JarvanIV'),(567,'Jax.png','24','Jax','Jax'),(568,'Jayce.png','126','Jayce','Jayce'),(569,'Jhin.png','202','Jhin','Jhin'),(570,'Jinx.png','222','Jinx','Jinx'),(571,'Kaisa.png','145','Kai\'Sa','Kaisa'),(572,'Kalista.png','429','Kalista','Kalista'),(573,'Karma.png','43','Karma','Karma'),(574,'Karthus.png','30','Karthus','Karthus'),(575,'Kassadin.png','38','Kassadin','Kassadin'),(576,'Katarina.png','55','Katarina','Katarina'),(577,'Kayle.png','10','Kayle','Kayle'),(578,'Kayn.png','141','Kayn','Kayn'),(579,'Kennen.png','85','Kennen','Kennen'),(580,'Khazix.png','121','Kha\'Zix','Khazix'),(581,'Kindred.png','203','Kindred','Kindred'),(582,'Kled.png','240','Kled','Kled'),(583,'KogMaw.png','96','Kog\'Maw','KogMaw'),(584,'KSante.png','897','K\'Sante','KSante'),(585,'Leblanc.png','7','LeBlanc','Leblanc'),(586,'LeeSin.png','64','Lee Sin','LeeSin'),(587,'Leona.png','89','Leona','Leona'),(588,'Lillia.png','876','Lillia','Lillia'),(589,'Lissandra.png','127','Lissandra','Lissandra'),(590,'Lucian.png','236','Lucian','Lucian'),(591,'Lulu.png','117','Lulu','Lulu'),(592,'Lux.png','99','Lux','Lux'),(593,'Malphite.png','54','Malphite','Malphite'),(594,'Malzahar.png','90','Malzahar','Malzahar'),(595,'Maokai.png','57','Maokai','Maokai'),(596,'MasterYi.png','11','Master Yi','MasterYi'),(597,'Mel.png','800','Mel','Mel'),(598,'Milio.png','902','Milio','Milio'),(599,'MissFortune.png','21','Miss Fortune','MissFortune'),(600,'MonkeyKing.png','62','Wukong','MonkeyKing'),(601,'Mordekaiser.png','82','Mordekaiser','Mordekaiser'),(602,'Morgana.png','25','Morgana','Morgana'),(603,'Naafiri.png','950','Naafiri','Naafiri'),(604,'Nami.png','267','Nami','Nami'),(605,'Nasus.png','75','Nasus','Nasus'),(606,'Nautilus.png','111','Nautilus','Nautilus'),(607,'Neeko.png','518','Neeko','Neeko'),(608,'Nidalee.png','76','Nidalee','Nidalee'),(609,'Nilah.png','895','Nilah','Nilah'),(610,'Nocturne.png','56','Nocturne','Nocturne'),(611,'Nunu.png','20','Nunu i Willump','Nunu'),(612,'Olaf.png','2','Olaf','Olaf'),(613,'Orianna.png','61','Orianna','Orianna'),(614,'Ornn.png','516','Ornn','Ornn'),(615,'Pantheon.png','80','Pantheon','Pantheon'),(616,'Poppy.png','78','Poppy','Poppy'),(617,'Pyke.png','555','Pyke','Pyke'),(618,'Qiyana.png','246','Qiyana','Qiyana'),(619,'Quinn.png','133','Quinn','Quinn'),(620,'Rakan.png','497','Rakan','Rakan'),(621,'Rammus.png','33','Rammus','Rammus'),(622,'RekSai.png','421','Rek\'Sai','RekSai'),(623,'Rell.png','526','Rell','Rell'),(624,'Renata.png','888','Renata Glasc','Renata'),(625,'Renekton.png','58','Renekton','Renekton'),(626,'Rengar.png','107','Rengar','Rengar'),(627,'Riven.png','92','Riven','Riven'),(628,'Rumble.png','68','Rumble','Rumble'),(629,'Ryze.png','13','Ryze','Ryze'),(630,'Samira.png','360','Samira','Samira'),(631,'Sejuani.png','113','Sejuani','Sejuani'),(632,'Senna.png','235','Senna','Senna'),(633,'Seraphine.png','147','Seraphine','Seraphine'),(634,'Sett.png','875','Sett','Sett'),(635,'Shaco.png','35','Shaco','Shaco'),(636,'Shen.png','98','Shen','Shen'),(637,'Shyvana.png','102','Shyvana','Shyvana'),(638,'Singed.png','27','Singed','Singed'),(639,'Sion.png','14','Sion','Sion'),(640,'Sivir.png','15','Sivir','Sivir'),(641,'Skarner.png','72','Skarner','Skarner'),(642,'Smolder.png','901','Smolder','Smolder'),(643,'Sona.png','37','Sona','Sona'),(644,'Soraka.png','16','Soraka','Soraka'),(645,'Swain.png','50','Swain','Swain'),(646,'Sylas.png','517','Sylas','Sylas'),(647,'Syndra.png','134','Syndra','Syndra'),(648,'TahmKench.png','223','Tahm Kench','TahmKench'),(649,'Taliyah.png','163','Taliyah','Taliyah'),(650,'Talon.png','91','Talon','Talon'),(651,'Taric.png','44','Taric','Taric'),(652,'Teemo.png','17','Teemo','Teemo'),(653,'Thresh.png','412','Thresh','Thresh'),(654,'Tristana.png','18','Tristana','Tristana'),(655,'Trundle.png','48','Trundle','Trundle'),(656,'Tryndamere.png','23','Tryndamere','Tryndamere'),(657,'TwistedFate.png','4','Twisted Fate','TwistedFate'),(658,'Twitch.png','29','Twitch','Twitch'),(659,'Udyr.png','77','Udyr','Udyr'),(660,'Urgot.png','6','Urgot','Urgot'),(661,'Varus.png','110','Varus','Varus'),(662,'Vayne.png','67','Vayne','Vayne'),(663,'Veigar.png','45','Veigar','Veigar'),(664,'Velkoz.png','161','Vel\'Koz','Velkoz'),(665,'Vex.png','711','Vex','Vex'),(666,'Vi.png','254','Vi','Vi'),(667,'Viego.png','234','Viego','Viego'),(668,'Viktor.png','112','Viktor','Viktor'),(669,'Vladimir.png','8','Vladimir','Vladimir'),(670,'Volibear.png','106','Volibear','Volibear'),(671,'Warwick.png','19','Warwick','Warwick'),(672,'Xayah.png','498','Xayah','Xayah'),(673,'Xerath.png','101','Xerath','Xerath'),(674,'XinZhao.png','5','Xin Zhao','XinZhao'),(675,'Yasuo.png','157','Yasuo','Yasuo'),(676,'Yone.png','777','Yone','Yone'),(677,'Yorick.png','83','Yorick','Yorick'),(678,'Yunara.png','804','Yunara','Yunara'),(679,'Yuumi.png','350','Yuumi','Yuumi'),(680,'Zaahen.png','904','Zaahen','Zaahen'),(681,'Zac.png','154','Zac','Zac'),(682,'Zed.png','238','Zed','Zed'),(683,'Zeri.png','221','Zeri','Zeri'),(684,'Ziggs.png','115','Ziggs','Ziggs'),(685,'Zilean.png','26','Zilean','Zilean'),(686,'Zoe.png','142','Zoe','Zoe'),(687,'Zyra.png','143','Zyra','Zyra');
/*!40000 ALTER TABLE `champions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-06  9:07:56
